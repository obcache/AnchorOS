# AnchorOS

## Why AnchorOS?
Govern your ChatGPT session data with portable, versioned capsules.

## Statement of Intent
Adaptability is a feature, not a flaw. Strictness where safety
and integrity are non-negotiable; flexibility where meaning and
creativity thrive.

## Getting Started
Upload BaseInstall bundle, then run:
| anchor init

## Commands
(see Guide v0.3 in this bundle)

_Last built: 2025-10-07T19:26:27Z_
